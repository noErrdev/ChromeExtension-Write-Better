(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
// See https://codepen.io/justiceo/pen/BaQZBqa?editors=1010
// Save options to chrome.storage
function save_options() {
    const access = document.getElementById('access-level').value;
    chrome.storage.sync.set({ 'access-level': access }, () => {
        const status = document.getElementById('status');
        status.textContent = 'Options saved.';
        setTimeout(() => {
            status.textContent = '';
        }, 750);
    });
}
function toggleSiteStatus() {
    const siteKey = `disabled-site-${location.hostname}`;
    chrome.storage.sync.get(siteKey, (data) => {
        if (data) {
            chrome.storage.sync.remove(siteKey, () => {
                // show notice.
                setTimeout(() => {
                    // clear notice
                }, 750);
            });
        }
        else {
            chrome.storage.sync.set({ siteKey: true }, () => {
                // show notice.
                setTimeout(() => {
                    // clear notice
                }, 750);
            });
        }
    });
}
// Restores select box state using the preferences
// stored in chrome.storage.
function restore_options() {
    chrome.storage.sync.get('access-level', (data) => {
        document.getElementById('access-level').id = data['access-level'];
    });
}
// https://developer.chrome.com/docs/extensions/reference/browserAction/
class BrowserAction {
    setIcon(details, callback) {
        chrome.browserAction.setIcon(details, callback);
    }
}
document.addEventListener('DOMContentLoaded', restore_options);
document.getElementById('save').addEventListener('click', save_options);

},{}]},{},[1]);
